from converter.App import App
import sys


app = App(sys.argv)
print(app.get_result_equation())
